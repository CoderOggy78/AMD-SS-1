import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { User, Target, Activity, Droplets } from 'lucide-react';

export function Profile() {
  const { user, updateProfile } = useAuth();
  
  const [formData, setFormData] = useState({
    age: user?.age || '',
    weight: user?.weight || '',
    height: user?.height || '',
    goal: user?.goal || 'maintenance',
    dietType: user?.dietType || 'veg',
    waterGoal: user?.waterGoal || 2500,
    waterReminders: user?.waterReminders ?? true,
  });

  const [saved, setSaved] = useState(false);

  // Calculate dynamic BMI
  const currentWeight = Number(formData.weight);
  const currentHeight = Number(formData.height);
  let dynamicBmi = 0;
  let dynamicBmiCategory = '';
  let dynamicBmiColor = 'text-gray-500';

  if (currentWeight > 0 && currentHeight > 0) {
    const heightInM = currentHeight / 100;
    dynamicBmi = currentWeight / (heightInM * heightInM);
    
    if (dynamicBmi < 18.5) {
      dynamicBmiCategory = 'Underweight';
      dynamicBmiColor = 'text-blue-500';
    } else if (dynamicBmi < 24.9) {
      dynamicBmiCategory = 'Normal weight';
      dynamicBmiColor = 'text-emerald-500';
    } else if (dynamicBmi < 29.9) {
      dynamicBmiCategory = 'Overweight';
      dynamicBmiColor = 'text-amber-500';
    } else {
      dynamicBmiCategory = 'Obese';
      dynamicBmiColor = 'text-red-500';
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      age: Number(formData.age),
      weight: Number(formData.weight),
      height: Number(formData.height),
      goal: formData.goal as any,
      dietType: formData.dietType as any,
      waterGoal: Number(formData.waterGoal),
      waterReminders: formData.waterReminders,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Profile & Goals</h1>
        <p className="text-gray-500 mt-1">Update your metrics to get personalized AI recommendations.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User size={20} className="text-emerald-600" />
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Input 
                  label="Age (years)" 
                  type="number" 
                  value={formData.age}
                  onChange={e => setFormData({...formData, age: e.target.value})}
                  required
                />
                <Input 
                  label="Weight (kg)" 
                  type="number" 
                  value={formData.weight}
                  onChange={e => setFormData({...formData, weight: e.target.value})}
                  required
                />
                <Input 
                  label="Height (cm)" 
                  type="number" 
                  value={formData.height}
                  onChange={e => setFormData({...formData, height: e.target.value})}
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4 border-t border-gray-100">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Primary Goal</label>
                  <select 
                    className="w-full h-11 rounded-xl border border-gray-300 bg-white px-4 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    value={formData.goal}
                    onChange={e => setFormData({...formData, goal: e.target.value})}
                  >
                    <option value="weight_loss">Weight Loss</option>
                    <option value="maintenance">Maintenance</option>
                    <option value="muscle_gain">Muscle Gain</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Dietary Preference</label>
                  <select 
                    className="w-full h-11 rounded-xl border border-gray-300 bg-white px-4 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    value={formData.dietType}
                    onChange={e => setFormData({...formData, dietType: e.target.value})}
                  >
                    <option value="veg">Vegetarian</option>
                    <option value="non-veg">Non-Vegetarian</option>
                    <option value="vegan">Vegan</option>
                    <option value="keto">Keto</option>
                  </select>
                </div>
              </div>

              <div className="pt-4 flex items-center gap-4">
                <Button type="submit">Save Changes</Button>
                {saved && <span className="text-emerald-600 text-sm font-medium">Profile updated successfully!</span>}
              </div>
            </form>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Droplets size={20} className="text-blue-500" />
              Hydration Settings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <Input 
                label="Daily Water Goal (ml)" 
                type="number" 
                value={formData.waterGoal}
                onChange={e => setFormData({...formData, waterGoal: Number(e.target.value)})}
                required
              />
              <div className="flex items-center gap-3 pt-6">
                <input 
                  type="checkbox" 
                  id="waterReminders"
                  checked={formData.waterReminders}
                  onChange={e => setFormData({...formData, waterReminders: e.target.checked})}
                  className="w-5 h-5 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                />
                <label htmlFor="waterReminders" className="text-sm font-medium text-gray-700">
                  Enable Water Reminders (Every 2 hours)
                </label>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6 md:col-start-3 md:row-start-1 md:row-span-2">
          <Card className="bg-emerald-900 text-white border-none">
            <CardContent className="p-6 text-center">
              <Target size={32} className="text-emerald-400 mx-auto mb-4" />
              <h3 className="text-emerald-100 font-medium mb-1">Daily Calorie Goal</h3>
              <p className="text-4xl font-bold">{user?.dailyCaloriesGoal || 2000}</p>
              <p className="text-sm text-emerald-300 mt-2">kcal / day</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <Activity size={32} className={`mx-auto mb-4 transition-colors ${dynamicBmi > 0 ? dynamicBmiColor : 'text-gray-400'}`} />
              <h3 className="text-gray-500 font-medium mb-1">Interactive BMI</h3>
              <p className={`text-4xl font-bold transition-colors ${dynamicBmi > 0 ? dynamicBmiColor : 'text-gray-900'}`}>
                {dynamicBmi > 0 ? dynamicBmi.toFixed(1) : '--'}
              </p>
              {dynamicBmi > 0 && (
                <p className={`mt-2 font-medium ${dynamicBmiColor}`}>{dynamicBmiCategory}</p>
              )}
              <p className="text-xs text-gray-400 mt-2">Updates as you type</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
