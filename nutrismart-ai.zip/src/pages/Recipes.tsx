import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { generateRecipes } from '../lib/gemini';
import { Card, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Loader2, Clock, Flame, ChefHat, Star, ChevronDown, ChevronUp, CalendarPlus, Filter } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function Recipes() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState<{mealOfTheDay: any, recommendations: any[]} | null>(null);
  const [loading, setLoading] = useState(false);
  const [expandedRecipe, setExpandedRecipe] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  // Filter states
  const [cuisine, setCuisine] = useState('Any');
  const [dietaryRestriction, setDietaryRestriction] = useState('Any');
  const [maxCookingTime, setMaxCookingTime] = useState('Any');

  const fetchRecipes = async (bypassCache = false) => {
    setLoading(true);
    try {
      const prefs = {
        goal: user?.goal || 'maintenance',
        dietType: user?.dietType || 'veg',
        dailyCalories: user?.dailyCaloriesGoal || 2000,
        cuisine,
        dietaryRestriction,
        maxCookingTime
      };
      const result = await generateRecipes(prefs);
      setData(result);
      
      // Only cache if no custom filters are applied
      if (cuisine === 'Any' && dietaryRestriction === 'Any' && maxCookingTime === 'Any') {
        localStorage.setItem('nutrismart_recipes_v3', JSON.stringify(result));
        localStorage.setItem('nutrismart_recipes_date_v3', new Date().toDateString());
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const cached = localStorage.getItem('nutrismart_recipes_v3');
    const cachedDate = localStorage.getItem('nutrismart_recipes_date_v3');
    const today = new Date().toDateString();

    if (cached && cachedDate === today) {
      setData(JSON.parse(cached));
    } else {
      fetchRecipes();
    }
  }, []);

  useEffect(() => {
    if (data && cuisine === 'Any' && dietaryRestriction === 'Any' && maxCookingTime === 'Any') {
      localStorage.setItem('nutrismart_recipes_v3', JSON.stringify(data));
      localStorage.setItem('nutrismart_recipes_date_v3', new Date().toDateString());
    }
  }, [data, cuisine, dietaryRestriction, maxCookingTime]);

  const handleSchedule = (recipeName: string) => {
    navigate('/planner');
  };

  const RecipeCard: React.FC<{ recipe: any, isFeatured?: boolean }> = ({ recipe, isFeatured = false }) => {
    const isExpanded = expandedRecipe === recipe.name;
    const imageUrl = `https://source.unsplash.com/800x600/?${encodeURIComponent(recipe.imageKeyword || recipe.name)}`;

    return (
      <Card className={`overflow-hidden transition-all duration-300 hover:shadow-lg flex flex-col h-full ${isFeatured ? 'border-2 border-emerald-500 shadow-emerald-100' : ''}`}>
        <div className={`h-48 w-full bg-gray-200 relative`}>
          <img 
            src={imageUrl} 
            alt={recipe.name} 
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).src = `https://source.unsplash.com/800x600/?food,meal`;
            }}
          />
          {isFeatured && (
            <div className="absolute top-4 left-4 bg-emerald-500 text-white px-3 py-1 rounded-full text-sm font-bold flex items-center gap-1 shadow-lg">
              <Star size={16} fill="currentColor" /> Meal of the Day
            </div>
          )}
          <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-bold text-gray-800 shadow-sm">
            {recipe.type}
          </div>
        </div>
        
        <CardContent className="p-6 flex-1 flex flex-col">
          <div className="flex justify-between items-start mb-2">
            <h3 className={`font-bold text-gray-900 ${isFeatured ? 'text-2xl' : 'text-xl'}`}>
              {recipe.name}
            </h3>
          </div>
          
          <p className="text-gray-600 mb-4 line-clamp-2 flex-1">{recipe.description}</p>
          
          <div className="flex flex-wrap gap-2 mb-6">
            <div className="flex items-center gap-1 text-sm font-medium text-gray-700 bg-gray-100 px-2 py-1 rounded-lg">
              <Clock size={14} className="text-blue-500" />
              {recipe.cookingTime}m
            </div>
            <div className="flex items-center gap-1 text-sm font-medium text-gray-700 bg-gray-100 px-2 py-1 rounded-lg">
              <Flame size={14} className="text-orange-500" />
              {recipe.calories} kcal
            </div>
            {recipe.difficulty && (
              <div className="flex items-center gap-1 text-sm font-medium text-gray-700 bg-gray-100 px-2 py-1 rounded-lg">
                <ChefHat size={14} className="text-purple-500" />
                {recipe.difficulty}
              </div>
            )}
          </div>

          <div className="flex gap-2">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={() => setExpandedRecipe(isExpanded ? null : recipe.name)}
            >
              {isExpanded ? 'Hide' : 'View'}
              {isExpanded ? <ChevronUp size={16} className="ml-2" /> : <ChevronDown size={16} className="ml-2" />}
            </Button>
            <Button variant="secondary" onClick={() => handleSchedule(recipe.name)}>
              <CalendarPlus size={18} />
            </Button>
          </div>

          {isExpanded && (
            <div className="mt-6 space-y-6 animate-in slide-in-from-top-4 duration-300">
              <div>
                <h4 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                  <span className="bg-emerald-100 text-emerald-600 w-6 h-6 rounded-full flex items-center justify-center text-sm">🛒</span>
                  Ingredients
                </h4>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {recipe.ingredients.map((ing: string, i: number) => (
                    <li key={i} className="flex items-center gap-2 text-gray-600 text-sm bg-gray-50 p-2 rounded-lg">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      {ing}
                    </li>
                  ))}
                </ul>
              </div>

              {recipe.instructions && (
                <div>
                  <h4 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <span className="bg-blue-100 text-blue-600 w-6 h-6 rounded-full flex items-center justify-center text-sm">👨‍🍳</span>
                    Instructions
                  </h4>
                  <ol className="space-y-3">
                    {recipe.instructions.map((step: string, i: number) => (
                      <li key={i} className="flex gap-3 text-gray-600 text-sm">
                        <span className="font-bold text-gray-400 shrink-0">{i + 1}.</span>
                        <p>{step}</p>
                      </li>
                    ))}
                  </ol>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Smart Recipes</h1>
          <p className="text-gray-500 mt-1">Personalized for your {user?.goal?.replace('_', ' ')} goal.</p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => setShowFilters(!showFilters)}
            className={showFilters ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : ''}
          >
            <Filter size={18} className="mr-2" /> Filters
          </Button>
          <Button onClick={() => fetchRecipes(true)} variant="default" disabled={loading}>
            {loading ? <Loader2 className="animate-spin" size={20} /> : 'Generate New'}
          </Button>
        </div>
      </div>

      {showFilters && (
        <Card className="bg-gray-50 border-gray-200 animate-in slide-in-from-top-2 duration-200">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Cuisine</label>
                <select 
                  value={cuisine} 
                  onChange={(e) => setCuisine(e.target.value)}
                  className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Any">Any Cuisine</option>
                  <option value="Italian">Italian</option>
                  <option value="Mexican">Mexican</option>
                  <option value="Asian">Asian</option>
                  <option value="Mediterranean">Mediterranean</option>
                  <option value="American">American</option>
                  <option value="Indian">Indian</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Dietary Restriction</label>
                <select 
                  value={dietaryRestriction} 
                  onChange={(e) => setDietaryRestriction(e.target.value)}
                  className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Any">Any Diet</option>
                  <option value="Vegan">Vegan</option>
                  <option value="Vegetarian">Vegetarian</option>
                  <option value="Keto">Keto</option>
                  <option value="Paleo">Paleo</option>
                  <option value="Gluten-Free">Gluten-Free</option>
                  <option value="Dairy-Free">Dairy-Free</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Max Cooking Time</label>
                <select 
                  value={maxCookingTime} 
                  onChange={(e) => setMaxCookingTime(e.target.value)}
                  className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Any">Any Time</option>
                  <option value="Under 15 mins">Under 15 mins</option>
                  <option value="Under 30 mins">Under 30 mins</option>
                  <option value="Under 45 mins">Under 45 mins</option>
                  <option value="Under 60 mins">Under 60 mins</option>
                </select>
              </div>
            </div>
            <div className="mt-4 flex justify-end">
              <Button onClick={() => fetchRecipes(true)} disabled={loading} size="sm">
                Apply Filters
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {loading && !data ? (
        <div className="flex flex-col items-center justify-center py-20 text-emerald-600">
          <Loader2 className="animate-spin mb-4" size={48} />
          <p className="text-gray-500 font-medium">AI is crafting your perfect menu...</p>
        </div>
      ) : data ? (
        <>
          {/* Meal of the Day */}
          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Star className="text-amber-400 fill-amber-400" /> Meal of the Day
            </h2>
            <RecipeCard recipe={data.mealOfTheDay} isFeatured={true} />
          </section>

          {/* Healthy Recommendations */}
          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Healthy Recommendations</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {data.recommendations.map((recipe, idx) => (
                <RecipeCard key={idx} recipe={recipe} />
              ))}
            </div>
          </section>
        </>
      ) : null}
    </div>
  );
}
