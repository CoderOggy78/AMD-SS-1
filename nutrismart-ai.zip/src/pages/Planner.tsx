import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Calendar as CalendarIcon, Plus, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';
import { format, addDays, startOfWeek, isSameDay } from 'date-fns';

export function Planner() {
  const { mealPlans, addMealPlan, removeMealPlan } = useData();
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const [showAdd, setShowAdd] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [mealType, setMealType] = useState('Breakfast');
  const [recipeName, setRecipeName] = useState('');

  const startDate = startOfWeek(currentDate, { weekStartsOn: 1 }); // Start on Monday
  const weekDays = Array.from({ length: 7 }).map((_, i) => addDays(startDate, i));

  const handleAddPlan = (e: React.FormEvent) => {
    e.preventDefault();
    if (recipeName) {
      addMealPlan({
        date: selectedDate,
        mealType,
        recipeName
      });
      setRecipeName('');
      setShowAdd(false);
    }
  };

  const nextWeek = () => setCurrentDate(addDays(currentDate, 7));
  const prevWeek = () => setCurrentDate(addDays(currentDate, -7));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Meal Planner</h1>
          <p className="text-gray-500 mt-1">Schedule your meals for the week.</p>
        </div>
        <Button onClick={() => setShowAdd(!showAdd)}>
          <Plus size={20} className="mr-2" /> Add Meal
        </Button>
      </div>

      {showAdd && (
        <Card className="bg-emerald-50 border-emerald-100">
          <CardContent className="p-6">
            <form onSubmit={handleAddPlan} className="flex flex-col md:flex-row gap-4 items-end">
              <div className="flex-1 w-full">
                <label className="block text-sm font-medium text-emerald-800 mb-1">Date</label>
                <input 
                  type="date" 
                  value={selectedDate}
                  onChange={e => setSelectedDate(e.target.value)}
                  className="w-full h-11 rounded-xl border border-emerald-200 bg-white px-4 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>
              <div className="flex-1 w-full">
                <label className="block text-sm font-medium text-emerald-800 mb-1">Meal Type</label>
                <select 
                  value={mealType}
                  onChange={e => setMealType(e.target.value)}
                  className="w-full h-11 rounded-xl border border-emerald-200 bg-white px-4 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option>Breakfast</option>
                  <option>Lunch</option>
                  <option>Dinner</option>
                  <option>Snack</option>
                </select>
              </div>
              <div className="flex-[2] w-full">
                <Input 
                  label="Recipe Name" 
                  placeholder="e.g., Avocado Toast" 
                  value={recipeName}
                  onChange={e => setRecipeName(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full md:w-auto">Save</Button>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="flex flex-row items-center justify-between border-b border-gray-100">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={prevWeek}><ChevronLeft size={20} /></Button>
            <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <CalendarIcon size={20} className="text-emerald-600" />
              {format(startDate, 'MMM d')} - {format(addDays(startDate, 6), 'MMM d, yyyy')}
            </h2>
            <Button variant="ghost" size="sm" onClick={nextWeek}><ChevronRight size={20} /></Button>
          </div>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <div className="min-w-[800px] grid grid-cols-7 divide-x divide-gray-100">
            {weekDays.map((day, i) => {
              const dateStr = format(day, 'yyyy-MM-dd');
              const dayPlans = mealPlans.filter(p => p.date === dateStr);
              const isToday = isSameDay(day, new Date());

              return (
                <div key={i} className={`min-h-[400px] ${isToday ? 'bg-emerald-50/30' : ''}`}>
                  <div className={`p-3 text-center border-b border-gray-100 ${isToday ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-50 text-gray-600'}`}>
                    <p className="text-xs font-bold uppercase tracking-wider">{format(day, 'EEE')}</p>
                    <p className={`text-xl ${isToday ? 'font-bold' : ''}`}>{format(day, 'd')}</p>
                  </div>
                  <div className="p-2 space-y-2">
                    {['Breakfast', 'Lunch', 'Dinner', 'Snack'].map(type => {
                      const meal = dayPlans.find(p => p.mealType === type);
                      return (
                        <div key={type} className="text-sm">
                          <p className="text-xs text-gray-400 font-medium mb-1">{type}</p>
                          {meal ? (
                            <div className="bg-white border border-emerald-100 p-2 rounded-lg shadow-sm relative group">
                              <p className="font-medium text-emerald-800 leading-tight">{meal.recipeName}</p>
                              <button 
                                onClick={() => removeMealPlan(meal.id)}
                                className="absolute top-1 right-1 text-red-400 opacity-0 group-hover:opacity-100 hover:text-red-600 transition-opacity"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          ) : (
                            <div 
                              onClick={() => {
                                setSelectedDate(dateStr);
                                setMealType(type);
                                setShowAdd(true);
                              }}
                              className="border border-dashed border-gray-200 p-2 rounded-lg text-gray-400 text-xs text-center cursor-pointer hover:bg-gray-50 hover:border-emerald-300 transition-colors"
                            >
                              + Add
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
