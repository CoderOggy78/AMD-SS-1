import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { useNavigate } from 'react-router-dom';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, AreaChart, Area, CartesianGrid, Legend, ComposedChart, Line } from 'recharts';
import { format } from 'date-fns';
import { Activity as ActivityIcon, Flame, Plus, Droplets, GlassWater } from 'lucide-react';

export function Dashboard() {
  const { user } = useAuth();
  const { getDailyTotals, foodLogs, addActivity, activities, getWaterByDate, addWaterLog } = useData();
  const navigate = useNavigate();

  const [actName, setActName] = useState('');
  const [actCals, setActCals] = useState('');
  const [timeRange, setTimeRange] = useState<7 | 30>(7);

  const today = new Date().toISOString();
  const totals = getDailyTotals(today);
  
  const dailyGoal = user?.dailyCaloriesGoal || 2000;
  const netCalories = totals.calories - totals.burned;
  const remaining = dailyGoal - netCalories;

  // BMI Calculation
  let bmi = 0;
  let bmiCategory = '';
  if (user?.weight && user?.height) {
    const heightInM = user.height / 100;
    bmi = user.weight / (heightInM * heightInM);
    if (bmi < 18.5) bmiCategory = 'Underweight';
    else if (bmi < 24.9) bmiCategory = 'Normal weight';
    else if (bmi < 29.9) bmiCategory = 'Overweight';
    else bmiCategory = 'Obese';
  }

  const macroData = [
    { name: 'Carbs', value: totals.carbs, color: '#10b981' }, // emerald-500
    { name: 'Protein', value: totals.protein, color: '#3b82f6' }, // blue-500
    { name: 'Fats', value: totals.fats, color: '#f59e0b' }, // amber-500
  ];

  // Real historical data for charts
  const historicalData = Array.from({ length: timeRange }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (timeRange - 1 - i)); // Ascending order (oldest to newest)
    const dateStr = d.toISOString();
    const dayTotals = getDailyTotals(dateStr);
    return {
      name: format(d, timeRange === 7 ? 'EEE' : 'MMM d'),
      consumed: dayTotals.calories,
      burned: dayTotals.burned,
      net: dayTotals.calories - dayTotals.burned,
      carbs: dayTotals.carbs,
      protein: dayTotals.protein,
      fats: dayTotals.fats,
    };
  });

  const handleAddActivity = (e: React.FormEvent) => {
    e.preventDefault();
    if (actName && actCals) {
      addActivity({
        date: today,
        name: actName,
        caloriesBurned: Number(actCals)
      });
      setActName('');
      setActCals('');
    }
  };

  const todayWaterLogs = getWaterByDate(today);
  const totalWater = todayWaterLogs.reduce((acc, log) => acc + log.amount, 0);
  const waterGoal = user?.waterGoal || 2500;
  const waterProgress = Math.min(100, (totalWater / waterGoal) * 100);

  // Check for water reminder
  const showWaterReminder = user?.waterReminders && (
    todayWaterLogs.length === 0 || 
    (new Date().getTime() - new Date(todayWaterLogs[todayWaterLogs.length - 1].date).getTime() > 2 * 60 * 60 * 1000)
  );

  return (
    <div className="space-y-6">
      {showWaterReminder && (
        <div className="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-3 rounded-xl flex items-center justify-between animate-in slide-in-from-top-2">
          <div className="flex items-center gap-3">
            <Droplets className="text-blue-500" />
            <p className="font-medium">Time to hydrate! You haven't logged water recently.</p>
          </div>
          <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white" onClick={() => addWaterLog(250)}>
            +250ml Now
          </Button>
        </div>
      )}

      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Hello, {user?.name?.split(' ')[0]}! 👋</h1>
          <p className="text-gray-500 mt-1">Here's your health summary for today.</p>
        </div>
        <Button onClick={() => navigate('/scan')} className="hidden sm:flex">
          Log Meal
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Calories Summary */}
        <Card className="md:col-span-2 bg-emerald-900 text-white border-none">
          <CardContent className="p-8 flex flex-col sm:flex-row items-center justify-between gap-8">
            <div className="space-y-4 flex-1">
              <h3 className="text-emerald-100 font-medium text-lg">Net Calories Remaining</h3>
              <div className="flex items-baseline gap-2">
                <span className="text-5xl font-bold">{Math.max(0, remaining)}</span>
                <span className="text-emerald-200">/ {dailyGoal} kcal</span>
              </div>
              <div className="w-full bg-emerald-800 rounded-full h-3 mt-4">
                <div 
                  className="bg-emerald-400 h-3 rounded-full transition-all duration-1000"
                  style={{ width: `${Math.min(100, (netCalories / dailyGoal) * 100)}%` }}
                />
              </div>
              <div className="flex gap-6 mt-4 text-sm">
                <div>
                  <span className="text-emerald-200 block">Consumed</span>
                  <span className="font-bold">{totals.calories} kcal</span>
                </div>
                <div>
                  <span className="text-emerald-200 block">Burned</span>
                  <span className="font-bold text-orange-400">{totals.burned} kcal</span>
                </div>
              </div>
            </div>
            
            <div className="w-32 h-32 relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={macroData}
                    innerRadius={40}
                    outerRadius={60}
                    paddingAngle={5}
                    dataKey="value"
                    stroke="none"
                  >
                    {macroData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex items-center justify-center flex-col">
                <span className="text-xs text-emerald-200">Net</span>
                <span className="font-bold">{netCalories}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Activity Input */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ActivityIcon size={20} className="text-orange-500" />
              Log Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddActivity} className="space-y-4">
              <Input 
                placeholder="e.g., Running 30 mins" 
                value={actName}
                onChange={e => setActName(e.target.value)}
                required
              />
              <div className="flex gap-2">
                <Input 
                  type="number" 
                  placeholder="Calories burned" 
                  value={actCals}
                  onChange={e => setActCals(e.target.value)}
                  required
                />
                <Button type="submit" variant="secondary" className="px-4">
                  <Plus size={20} />
                </Button>
              </div>
            </form>
            
            <div className="mt-4 space-y-2">
              {activities.filter(a => a.date.startsWith(today.split('T')[0])).slice(-3).map(act => (
                <div key={act.id} className="flex justify-between items-center text-sm p-2 bg-gray-50 rounded-lg">
                  <span className="text-gray-700">{act.name}</span>
                  <span className="text-orange-600 font-medium flex items-center gap-1">
                    <Flame size={14} /> {act.caloriesBurned}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Water Tracker */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-600">
              <Droplets size={20} />
              Water Tracker
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center space-y-4">
              <div className="relative w-32 h-32 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90">
                  <circle cx="64" cy="64" r="56" className="stroke-gray-100" strokeWidth="12" fill="none" />
                  <circle 
                    cx="64" cy="64" r="56" 
                    className="stroke-blue-500 transition-all duration-1000 ease-out" 
                    strokeWidth="12" fill="none" 
                    strokeDasharray="351.86" 
                    strokeDashoffset={351.86 - (351.86 * waterProgress) / 100}
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold text-gray-900">{totalWater}</span>
                  <span className="text-xs text-gray-500">/ {waterGoal} ml</span>
                </div>
              </div>
              
              <div className="flex gap-2 w-full">
                <Button variant="outline" className="flex-1 text-blue-600 border-blue-200 hover:bg-blue-50" onClick={() => addWaterLog(250)}>
                  <GlassWater size={16} className="mr-1" /> +250ml
                </Button>
                <Button variant="outline" className="flex-1 text-blue-600 border-blue-200 hover:bg-blue-50" onClick={() => addWaterLog(500)}>
                  <Droplets size={16} className="mr-1" /> +500ml
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Historical Trends Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Progress & Trends</h2>
          <div className="flex bg-gray-100 p-1 rounded-xl">
            <button 
              onClick={() => setTimeRange(7)} 
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${timeRange === 7 ? 'bg-white text-emerald-700 shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
            >
              7 Days
            </button>
            <button 
              onClick={() => setTimeRange(30)} 
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${timeRange === 30 ? 'bg-white text-emerald-700 shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
            >
              30 Days
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Calorie Trend */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Calories: Consumed vs Burned</CardTitle>
            </CardHeader>
            <CardContent className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={historicalData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#6b7280', fontSize: 12 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#6b7280', fontSize: 12 }} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} 
                  />
                  <Legend iconType="circle" wrapperStyle={{ fontSize: '12px' }} />
                  <Area type="monotone" dataKey="consumed" name="Consumed" fill="#10b981" stroke="#10b981" fillOpacity={0.2} />
                  <Line type="monotone" dataKey="burned" name="Burned" stroke="#f59e0b" strokeWidth={2} dot={false} />
                </ComposedChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Macro Trend */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Macronutrient Breakdown (g)</CardTitle>
            </CardHeader>
            <CardContent className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={historicalData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#6b7280', fontSize: 12 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#6b7280', fontSize: 12 }} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} 
                  />
                  <Legend iconType="circle" wrapperStyle={{ fontSize: '12px' }} />
                  <Bar dataKey="carbs" name="Carbs" stackId="a" fill="#10b981" radius={[0, 0, 4, 4]} />
                  <Bar dataKey="protein" name="Protein" stackId="a" fill="#3b82f6" />
                  <Bar dataKey="fats" name="Fats" stackId="a" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Smart Meal History */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Today's Smart Meal History</CardTitle>
          <Button variant="ghost" size="sm" onClick={() => navigate('/scan')}>+ Add</Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {foodLogs.filter(log => log.date.startsWith(today.split('T')[0])).length === 0 ? (
              <p className="text-center text-gray-500 py-8">No meals logged today yet.</p>
            ) : (
              foodLogs.filter(log => log.date.startsWith(today.split('T')[0])).map((log) => (
                <div key={log.id} className="flex flex-col gap-2 p-3 rounded-xl border border-gray-100 hover:border-emerald-200 transition-colors">
                  <div className="flex items-center gap-4">
                    {log.imageUrl ? (
                      <img src={log.imageUrl} alt="Food" className="w-16 h-16 rounded-lg object-cover" />
                    ) : (
                      <div className="w-16 h-16 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-600 font-bold">
                        {log.mealType[0]}
                      </div>
                    )}
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-medium text-gray-900">{log.mealType}</h4>
                        {log.healthRating && (
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                            log.healthRating >= 8 ? 'bg-emerald-100 text-emerald-700' :
                            log.healthRating >= 5 ? 'bg-amber-100 text-amber-700' :
                            'bg-red-100 text-red-700'
                          }`}>
                            {log.healthRating}/10 Health
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-500 truncate">{log.foodItems.join(', ')}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-gray-900">{log.totalCalories}</p>
                      <p className="text-xs text-gray-500">kcal</p>
                    </div>
                  </div>
                  {log.foodSwap && (
                    <div className="mt-2 text-sm bg-amber-50 text-amber-800 p-2 rounded-lg border border-amber-100">
                      💡 <strong>Swap:</strong> {log.foodSwap}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
