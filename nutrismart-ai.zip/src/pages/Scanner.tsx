import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../context/DataContext';
import { analyzeFoodImage, generateFoodSwap } from '../lib/gemini';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Camera, Upload, Loader2, CheckCircle2, Barcode, Image as ImageIcon } from 'lucide-react';
import { Html5QrcodeScanner, Html5QrcodeScanType } from 'html5-qrcode';

export function Scanner() {
  const [scanMode, setScanMode] = useState<'image' | 'barcode'>('image');
  const [image, setImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [mealType, setMealType] = useState<'Breakfast' | 'Lunch' | 'Dinner' | 'Snack'>('Lunch');
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { addFoodLog } = useData();
  const navigate = useNavigate();

  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      setImage(reader.result as string);
      setResult(null);
    };
    reader.readAsDataURL(file);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      processFile(file);
    }
  };

  useEffect(() => {
    let scanner: Html5QrcodeScanner | null = null;
    
    if (scanMode === 'barcode' && !result) {
      scanner = new Html5QrcodeScanner(
        "reader",
        { 
          fps: 10, 
          qrbox: { width: 250, height: 150 },
          supportedScanTypes: [Html5QrcodeScanType.SCAN_TYPE_CAMERA]
        },
        false
      );

      scanner.render(
        async (decodedText) => {
          if (scanner) {
            scanner.clear();
          }
          await fetchProductData(decodedText);
        },
        (error) => {
          // ignore background scan errors
        }
      );
    }

    return () => {
      if (scanner) {
        scanner.clear().catch(console.error);
      }
    };
  }, [scanMode, result]);

  const fetchProductData = async (barcode: string) => {
    setLoading(true);
    try {
      const res = await fetch(`https://world.openfoodfacts.org/api/v0/product/${barcode}.json`);
      const data = await res.json();
      
      if (data.status === 1 && data.product) {
        const p = data.product;
        const nutriments = p.nutriments || {};
        const productName = p.product_name || 'Unknown Packaged Food';
        const cals = Math.round(nutriments['energy-kcal_100g'] || nutriments['energy-kcal'] || 0);
        const healthRating = p.nutriscore_score !== undefined ? Math.max(1, 10 - Math.floor((p.nutriscore_score + 15) / 4)) : undefined;
        
        let foodSwap;
        if ((healthRating && healthRating < 7) || cals > 400) {
          foodSwap = await generateFoodSwap(productName, cals);
        }

        setResult({
          foodItems: [productName],
          totalCalories: cals,
          macros: {
            carbs: Math.round(nutriments['carbohydrates_100g'] || nutriments['carbohydrates'] || 0),
            protein: Math.round(nutriments['proteins_100g'] || nutriments['proteins'] || 0),
            fats: Math.round(nutriments['fat_100g'] || nutriments['fat'] || 0),
          },
          healthRating,
          foodSwap
        });
      } else {
        alert("Product not found in database.");
        setScanMode('image');
      }
    } catch (error) {
      console.error(error);
      alert("Error fetching product data.");
      setScanMode('image');
    } finally {
      setLoading(false);
    }
  };

  const handleAnalyze = async () => {
    if (!image) return;
    setLoading(true);
    try {
      // Extract base64 and mime type
      const [prefix, base64] = image.split(',');
      const mimeType = prefix.split(':')[1].split(';')[0];
      
      const analysis = await analyzeFoodImage(base64, mimeType);
      setResult(analysis);
    } catch (error) {
      alert("Failed to analyze image. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = () => {
    if (result) {
      addFoodLog({
        date: new Date().toISOString(),
        foodItems: result.foodItems,
        totalCalories: result.totalCalories,
        macros: result.macros,
        imageUrl: image || undefined,
        mealType,
        healthRating: result.healthRating,
        foodSwap: result.foodSwap,
      });
      navigate('/dashboard');
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Scan Food</h1>
          <p className="text-gray-500 mt-1">Upload a photo or scan a barcode to track calories automatically.</p>
        </div>
        {!result && (
          <div className="flex bg-gray-100 p-1 rounded-xl">
            <button
              onClick={() => setScanMode('image')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                scanMode === 'image' ? 'bg-white text-emerald-700 shadow-sm' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <ImageIcon size={16} /> Photo
            </button>
            <button
              onClick={() => setScanMode('barcode')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                scanMode === 'barcode' ? 'bg-white text-emerald-700 shadow-sm' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Barcode size={16} /> Barcode
            </button>
          </div>
        )}
      </div>

      <Card>
        <CardContent className="p-6">
          {scanMode === 'barcode' && !result ? (
            <div className="space-y-4">
              <div id="reader" className="w-full max-w-sm mx-auto overflow-hidden rounded-2xl border-2 border-emerald-100"></div>
              <p className="text-center text-sm text-gray-500">Point your camera at a product barcode</p>
              {loading && <p className="text-center text-emerald-600 font-medium animate-pulse">Fetching product data...</p>}
            </div>
          ) : !image ? (
            <div 
              onClick={() => fileInputRef.current?.click()}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all duration-200 ${
                isDragging 
                  ? 'border-emerald-500 bg-emerald-50 scale-[1.02]' 
                  : 'border-gray-300 hover:bg-gray-50 hover:border-emerald-400'
              }`}
            >
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-emerald-600">
                <Camera size={32} />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {isDragging ? 'Drop image here' : 'Tap or drag to upload photo'}
              </h3>
              <p className="text-gray-500 text-sm">Support JPG, PNG</p>
              <input 
                type="file" 
                accept="image/*" 
                className="hidden" 
                ref={fileInputRef}
                onChange={handleImageUpload}
              />
            </div>
          ) : (
            <div className="space-y-6">
              <div className="relative rounded-2xl overflow-hidden bg-gray-100 h-64 sm:h-96">
                <img src={image} alt="Food" className="w-full h-full object-contain" />
                <button 
                  onClick={() => { setImage(null); setResult(null); }}
                  className="absolute top-4 right-4 bg-white/90 p-2 rounded-full shadow-sm text-gray-700 hover:bg-white"
                >
                  ✕
                </button>
              </div>

              {!result && scanMode === 'image' && (
                <Button 
                  onClick={handleAnalyze} 
                  disabled={loading}
                  className="w-full"
                  size="lg"
                >
                  {loading ? (
                    <><Loader2 className="animate-spin mr-2" size={20} /> Analyzing with AI...</>
                  ) : (
                    <><Upload className="mr-2" size={20} /> Analyze Meal</>
                  )}
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {result && (
        <Card className="border-emerald-200 shadow-emerald-100/50">
          <CardHeader className="bg-emerald-50/50 border-b border-emerald-100 flex flex-row items-center justify-between">
            <div className="flex items-center gap-2 text-emerald-700">
              <CheckCircle2 size={24} />
              <CardTitle>Analysis Complete</CardTitle>
            </div>
            <Button variant="ghost" size="sm" onClick={() => { setResult(null); setImage(null); }}>
              Scan Another
            </Button>
          </CardHeader>
          <CardContent className="space-y-6 pt-6">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="bg-gray-50 p-4 rounded-xl text-center">
                <p className="text-sm text-gray-500 mb-1">Calories</p>
                <p className="text-2xl font-bold text-gray-900">{result.totalCalories}</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-xl text-center">
                <p className="text-sm text-gray-500 mb-1">Carbs</p>
                <p className="text-2xl font-bold text-emerald-600">{result.macros.carbs}g</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-xl text-center">
                <p className="text-sm text-gray-500 mb-1">Protein</p>
                <p className="text-2xl font-bold text-blue-600">{result.macros.protein}g</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-xl text-center">
                <p className="text-sm text-gray-500 mb-1">Fats</p>
                <p className="text-2xl font-bold text-amber-600">{result.macros.fats}g</p>
              </div>
            </div>

            {result.healthRating && (
              <div className="flex items-center justify-between bg-emerald-50 p-4 rounded-xl border border-emerald-100">
                <div>
                  <p className="text-sm font-medium text-emerald-800">Health Rating</p>
                  <p className="text-xs text-emerald-600 mt-1">Based on macros & ingredients</p>
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-2xl font-bold text-emerald-700">{result.healthRating}</span>
                  <span className="text-emerald-600 font-medium">/ 10</span>
                </div>
              </div>
            )}

            {result.foodSwap && (
              <div className="bg-amber-50 p-4 rounded-xl border border-amber-100">
                <p className="text-sm font-medium text-amber-800 mb-1">💡 AI Food Swap Suggestion</p>
                <p className="text-sm text-amber-700">{result.foodSwap}</p>
              </div>
            )}

            <div>
              <h4 className="font-medium text-gray-900 mb-2">Detected Items:</h4>
              <div className="flex flex-wrap gap-2">
                {result.foodItems.map((item: string, i: number) => (
                  <span key={i} className="bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full text-sm font-medium">
                    {item}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-gray-100">
              <label className="block text-sm font-medium text-gray-700 mb-2">Meal Type</label>
              <div className="flex gap-2">
                {['Breakfast', 'Lunch', 'Dinner', 'Snack'].map((type) => (
                  <button
                    key={type}
                    onClick={() => setMealType(type as any)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      mealType === type 
                        ? 'bg-emerald-600 text-white' 
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            <Button onClick={handleSave} className="w-full" size="lg">
              Log to Diary
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
