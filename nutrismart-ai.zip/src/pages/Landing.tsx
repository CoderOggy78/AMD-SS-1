import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Activity, Camera, TrendingUp, Heart } from 'lucide-react';
import { motion } from 'motion/react';

export function Landing() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleStart = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && name) {
      login(email, name);
      navigate('/dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-emerald-900 text-white">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-1/2 -right-1/4 w-full h-full bg-emerald-800 rounded-full blur-3xl opacity-50" />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-32 relative z-10">
          <div className="flex items-center gap-3 mb-12">
            <div className="bg-emerald-500 p-2 rounded-xl">
              <Activity size={28} />
            </div>
            <span className="text-2xl font-bold">NutriSmart AI</span>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight mb-6 leading-tight">
                Your Personal <br/>
                <span className="text-emerald-400">AI Nutrition</span> Assistant
              </h1>
              <p className="text-xl text-emerald-100 mb-8 max-w-lg">
                Snap a photo of your meal to track calories, get personalized recipes, and achieve your health goals effortlessly.
              </p>
              
              <form onSubmit={handleStart} className="bg-white p-6 rounded-2xl shadow-xl max-w-md">
                <h3 className="text-gray-900 font-semibold text-lg mb-4">Start Your Healthy Journey</h3>
                <div className="space-y-4 mb-6">
                  <Input 
                    placeholder="Your Name" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                  <Input 
                    type="email" 
                    placeholder="Email Address" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                <Button type="submit" className="w-full" size="lg">
                  Get Started Now
                </Button>
              </form>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="hidden md:block relative"
            >
              <img 
                src="https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&w=800&q=80" 
                alt="Healthy Food" 
                className="rounded-3xl shadow-2xl object-cover h-[500px] w-full"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl text-gray-900 flex items-center gap-4">
                <div className="bg-emerald-100 p-3 rounded-full text-emerald-600">
                  <Camera size={24} />
                </div>
                <div>
                  <p className="text-sm text-gray-500 font-medium">AI Detected</p>
                  <p className="font-bold text-lg">Avocado Toast • 320 kcal</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">How NutriSmart Works</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">Everything you need to build better eating habits, powered by advanced AI.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            { icon: Camera, title: 'Snap & Track', desc: 'Take a photo of your food. Our AI instantly identifies it and calculates calories and macros.' },
            { icon: TrendingUp, title: 'Smart Dashboard', desc: 'Monitor your daily intake, track your BMI, and see your progress over time.' },
            { icon: Heart, title: 'Personalized Recipes', desc: 'Get daily recipe recommendations tailored to your goals and dietary preferences.' }
          ].map((feature, i) => (
            <div key={i} className="bg-gray-50 p-8 rounded-3xl text-center hover:shadow-lg transition-shadow">
              <div className="bg-emerald-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 text-emerald-600">
                <feature.icon size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
