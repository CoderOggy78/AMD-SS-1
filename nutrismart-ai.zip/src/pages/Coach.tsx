import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { chatWithCoach, getWeeklyInsights } from '../lib/gemini';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { MessageSquare, Send, Bot, User as UserIcon, Loader2, Sparkles } from 'lucide-react';

export function Coach() {
  const { user } = useAuth();
  const { foodLogs } = useData();
  const [messages, setMessages] = useState<{role: 'user'|'coach', text: string}[]>([
    { role: 'coach', text: `Hi ${user?.name?.split(' ')[0]}! I'm your AI Nutrition Coach. How can I help you reach your ${user?.goal?.replace('_', ' ')} goal today?` }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [insights, setInsights] = useState<string[]>([]);

  useEffect(() => {
    if (foodLogs.length > 0) {
      getWeeklyInsights(foodLogs).then(setInsights);
    }
  }, [foodLogs]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMsg = input;
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInput('');
    setLoading(true);

    try {
      const response = await chatWithCoach(userMsg, user, foodLogs);
      setMessages(prev => [...prev, { role: 'coach', text: response }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'coach', text: "Sorry, I'm having trouble connecting right now. Please try again later." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-8rem)]">
      {/* Chat Area */}
      <Card className="lg:col-span-2 flex flex-col h-full">
        <CardHeader className="bg-emerald-50 border-b border-emerald-100">
          <CardTitle className="flex items-center gap-2 text-emerald-800">
            <Bot size={24} /> AI Nutrition Coach
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg, i) => (
            <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                msg.role === 'user' ? 'bg-blue-100 text-blue-600' : 'bg-emerald-100 text-emerald-600'
              }`}>
                {msg.role === 'user' ? <UserIcon size={16} /> : <Bot size={16} />}
              </div>
              <div className={`max-w-[80%] rounded-2xl p-4 ${
                msg.role === 'user' 
                  ? 'bg-blue-600 text-white rounded-tr-sm' 
                  : 'bg-gray-100 text-gray-800 rounded-tl-sm'
              }`}>
                <p className="whitespace-pre-wrap text-sm leading-relaxed">{msg.text}</p>
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                <Bot size={16} />
              </div>
              <div className="bg-gray-100 rounded-2xl rounded-tl-sm p-4 flex items-center gap-2">
                <Loader2 size={16} className="animate-spin text-gray-500" />
                <span className="text-sm text-gray-500">Coach is typing...</span>
              </div>
            </div>
          )}
        </CardContent>
        <div className="p-4 border-t border-gray-100 bg-white">
          <form onSubmit={handleSend} className="flex gap-2">
            <Input 
              placeholder="Ask about your diet, e.g., 'What should I eat today?'" 
              value={input}
              onChange={e => setInput(e.target.value)}
              className="flex-1"
            />
            <Button type="submit" disabled={loading || !input.trim()}>
              <Send size={18} />
            </Button>
          </form>
        </div>
      </Card>

      {/* Insights Sidebar */}
      <div className="space-y-6">
        <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-100">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-emerald-800">
              <Sparkles size={20} /> Weekly Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            {insights.length > 0 ? (
              <ul className="space-y-4">
                {insights.map((insight, i) => (
                  <li key={i} className="flex gap-3 text-sm text-emerald-900 bg-white/60 p-3 rounded-xl border border-emerald-100/50">
                    <span className="text-emerald-500 font-bold">•</span>
                    {insight}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-emerald-600/70 text-center py-4">
                Log more meals to get personalized weekly insights!
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm text-gray-500 uppercase tracking-wider">Suggested Questions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {[
              "What should I eat for dinner?",
              "Is my current diet good for fat loss?",
              "How can I get more protein?",
              "Suggest a healthy late-night snack."
            ].map((q, i) => (
              <button 
                key={i}
                onClick={() => setInput(q)}
                className="w-full text-left text-sm p-3 rounded-xl bg-gray-50 hover:bg-emerald-50 hover:text-emerald-700 transition-colors border border-transparent hover:border-emerald-100"
              >
                "{q}"
              </button>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
