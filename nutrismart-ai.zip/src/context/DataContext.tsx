import React, { createContext, useContext, useState, useEffect } from 'react';

export interface FoodLog {
  id: string;
  date: string; // ISO string
  foodItems: string[];
  totalCalories: number;
  macros: {
    carbs: number;
    protein: number;
    fats: number;
  };
  imageUrl?: string;
  mealType: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
  healthRating?: number;
  foodSwap?: string;
}

export interface Activity {
  id: string;
  date: string;
  name: string;
  caloriesBurned: number;
}

export interface PlannedMeal {
  id: string;
  date: string; // YYYY-MM-DD
  mealType: string;
  recipeName: string;
}

export interface WaterLog {
  id: string;
  date: string; // ISO string
  amount: number; // in ml
}

interface DataContextType {
  foodLogs: FoodLog[];
  activities: Activity[];
  mealPlans: PlannedMeal[];
  waterLogs: WaterLog[];
  addFoodLog: (log: Omit<FoodLog, 'id'>) => void;
  deleteFoodLog: (id: string) => void;
  addActivity: (activity: Omit<Activity, 'id'>) => void;
  addMealPlan: (plan: Omit<PlannedMeal, 'id'>) => void;
  removeMealPlan: (id: string) => void;
  addWaterLog: (amount: number) => void;
  getLogsByDate: (date: string) => FoodLog[];
  getActivitiesByDate: (date: string) => Activity[];
  getWaterByDate: (date: string) => WaterLog[];
  getDailyTotals: (date: string) => { calories: number; carbs: number; protein: number; fats: number; burned: number };
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: React.ReactNode }) {
  const [foodLogs, setFoodLogs] = useState<FoodLog[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [mealPlans, setMealPlans] = useState<PlannedMeal[]>([]);
  const [waterLogs, setWaterLogs] = useState<WaterLog[]>([]);

  useEffect(() => {
    const storedLogs = localStorage.getItem('nutrismart_logs');
    if (storedLogs) setFoodLogs(JSON.parse(storedLogs));
    
    const storedActivities = localStorage.getItem('nutrismart_activities');
    if (storedActivities) setActivities(JSON.parse(storedActivities));

    const storedPlans = localStorage.getItem('nutrismart_plans');
    if (storedPlans) setMealPlans(JSON.parse(storedPlans));

    const storedWater = localStorage.getItem('nutrismart_water');
    if (storedWater) setWaterLogs(JSON.parse(storedWater));
  }, []);

  const addFoodLog = (log: Omit<FoodLog, 'id'>) => {
    const newLog = { ...log, id: Math.random().toString(36).substring(7) };
    const updatedLogs = [...foodLogs, newLog];
    setFoodLogs(updatedLogs);
    localStorage.setItem('nutrismart_logs', JSON.stringify(updatedLogs));
  };

  const deleteFoodLog = (id: string) => {
    const updatedLogs = foodLogs.filter(log => log.id !== id);
    setFoodLogs(updatedLogs);
    localStorage.setItem('nutrismart_logs', JSON.stringify(updatedLogs));
  };

  const addActivity = (activity: Omit<Activity, 'id'>) => {
    const newAct = { ...activity, id: Math.random().toString(36).substring(7) };
    const updated = [...activities, newAct];
    setActivities(updated);
    localStorage.setItem('nutrismart_activities', JSON.stringify(updated));
  };

  const addMealPlan = (plan: Omit<PlannedMeal, 'id'>) => {
    const newPlan = { ...plan, id: Math.random().toString(36).substring(7) };
    const updated = [...mealPlans, newPlan];
    setMealPlans(updated);
    localStorage.setItem('nutrismart_plans', JSON.stringify(updated));
  };

  const removeMealPlan = (id: string) => {
    const updated = mealPlans.filter(p => p.id !== id);
    setMealPlans(updated);
    localStorage.setItem('nutrismart_plans', JSON.stringify(updated));
  };

  const addWaterLog = (amount: number) => {
    const newLog = { id: Math.random().toString(36).substring(7), date: new Date().toISOString(), amount };
    const updated = [...waterLogs, newLog];
    setWaterLogs(updated);
    localStorage.setItem('nutrismart_water', JSON.stringify(updated));
  };

  const getLogsByDate = (date: string) => {
    return foodLogs.filter(log => log.date.startsWith(date.split('T')[0]));
  };

  const getActivitiesByDate = (date: string) => {
    return activities.filter(act => act.date.startsWith(date.split('T')[0]));
  };

  const getWaterByDate = (date: string) => {
    return waterLogs.filter(log => log.date.startsWith(date.split('T')[0]));
  };

  const getDailyTotals = (date: string) => {
    const logs = getLogsByDate(date);
    const acts = getActivitiesByDate(date);
    
    const burned = acts.reduce((acc, act) => acc + act.caloriesBurned, 0);
    
    return logs.reduce(
      (acc, log) => ({
        calories: acc.calories + log.totalCalories,
        carbs: acc.carbs + log.macros.carbs,
        protein: acc.protein + log.macros.protein,
        fats: acc.fats + log.macros.fats,
        burned: acc.burned,
      }),
      { calories: 0, carbs: 0, protein: 0, fats: 0, burned }
    );
  };

  return (
    <DataContext.Provider value={{ 
      foodLogs, activities, mealPlans, waterLogs,
      addFoodLog, deleteFoodLog, addActivity, addMealPlan, removeMealPlan, addWaterLog,
      getLogsByDate, getActivitiesByDate, getWaterByDate, getDailyTotals 
    }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}
