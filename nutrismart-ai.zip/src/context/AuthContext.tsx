import React, { createContext, useContext, useState, useEffect } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  age?: number;
  weight?: number; // in kg
  height?: number; // in cm
  goal?: 'weight_loss' | 'maintenance' | 'muscle_gain';
  dietType?: 'veg' | 'non-veg' | 'vegan' | 'keto';
  dailyCaloriesGoal?: number;
  waterGoal?: number; // in ml
  waterReminders?: boolean;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, name: string) => void;
  logout: () => void;
  updateProfile: (data: Partial<User>) => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('nutrismart_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const login = (email: string, name: string) => {
    // Mock login
    const newUser: User = {
      id: Math.random().toString(36).substring(7),
      email,
      name,
      goal: 'maintenance',
      dietType: 'veg',
      dailyCaloriesGoal: 2000,
      waterGoal: 2500,
      waterReminders: true,
    };
    setUser(newUser);
    localStorage.setItem('nutrismart_user', JSON.stringify(newUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('nutrismart_user');
  };

  const updateProfile = (data: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...data };
      
      // Calculate BMI and suggested calories if weight/height/goal changed
      if (updatedUser.weight && updatedUser.height && updatedUser.age) {
        // BMR Calculation (Mifflin-St Jeor Equation - simplified)
        const bmr = 10 * updatedUser.weight + 6.25 * updatedUser.height - 5 * updatedUser.age + 5;
        
        let targetCalories = bmr * 1.2; // Sedentary multiplier
        if (updatedUser.goal === 'weight_loss') targetCalories -= 500;
        if (updatedUser.goal === 'muscle_gain') targetCalories += 300;
        
        updatedUser.dailyCaloriesGoal = Math.round(targetCalories);
      }

      setUser(updatedUser);
      localStorage.setItem('nutrismart_user', JSON.stringify(updatedUser));
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, updateProfile, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
