import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function analyzeFoodImage(base64Image: string, mimeType: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          inlineData: {
            data: base64Image,
            mimeType: mimeType,
          },
        },
        "Analyze this food image. Identify the food items, estimate the total calories, and provide a macronutrient breakdown (carbs, protein, fats in grams). Also provide a health rating (1-10). If the food is unhealthy (rating < 7) or high calorie (> 400 kcal), provide a healthy food swap suggestion (e.g., 'Replace fried rice with brown rice for -120 kcal'). If it is healthy, leave foodSwap empty. Provide a confidence score between 0 and 100.",
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            foodItems: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "List of identified food items",
            },
            totalCalories: {
              type: Type.NUMBER,
              description: "Estimated total calories",
            },
            macros: {
              type: Type.OBJECT,
              properties: {
                carbs: { type: Type.NUMBER, description: "Carbohydrates in grams" },
                protein: { type: Type.NUMBER, description: "Protein in grams" },
                fats: { type: Type.NUMBER, description: "Fats in grams" },
              },
              required: ["carbs", "protein", "fats"],
            },
            healthRating: {
              type: Type.NUMBER,
              description: "Health rating from 1 to 10",
            },
            foodSwap: {
              type: Type.STRING,
              description: "A healthy alternative suggestion",
            },
            confidenceScore: {
              type: Type.NUMBER,
              description: "Confidence score from 0 to 100",
            },
          },
          required: ["foodItems", "totalCalories", "macros", "healthRating", "confidenceScore"],
        },
      },
    });

    if (response.text) {
      return JSON.parse(response.text);
    }
    throw new Error("No response from AI");
  } catch (error) {
    console.error("Error analyzing food image:", error);
    throw error;
  }
}

export async function generateRecipes(preferences: any) {
  try {
    let prompt = `Generate healthy recipe recommendations based on these user preferences:
    Goal: ${preferences.goal}
    Diet: ${preferences.dietType}
    Calories Target per meal: ~${Math.round(preferences.dailyCalories / 3)} kcal.`;

    if (preferences.cuisine && preferences.cuisine !== 'Any') {
      prompt += `\n    Cuisine Type: ${preferences.cuisine}`;
    }
    if (preferences.dietaryRestriction && preferences.dietaryRestriction !== 'Any') {
      prompt += `\n    Specific Dietary Restriction: ${preferences.dietaryRestriction}`;
    }
    if (preferences.maxCookingTime && preferences.maxCookingTime !== 'Any') {
      prompt += `\n    Maximum Cooking Time: ${preferences.maxCookingTime}`;
    }

    prompt += `
    
    Provide:
    1. A special "Meal of the Day" that is highly nutritious and visually appealing.
    2. A list of 3 other healthy recipe recommendations.
    
    For each, provide the recipe name, a short description, cooking time in minutes, difficulty (Easy/Medium/Hard), estimated calories, a list of ingredients, step-by-step cooking instructions, and a single keyword for an image search.`;

    const recipeSchema = {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING },
        description: { type: Type.STRING },
        cookingTime: { type: Type.NUMBER },
        difficulty: { type: Type.STRING },
        calories: { type: Type.NUMBER },
        ingredients: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
        instructions: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
        imageKeyword: { type: Type.STRING },
        type: { type: Type.STRING, description: "e.g., Breakfast, Lunch, Dinner, Snack" }
      },
      required: ["name", "description", "cookingTime", "difficulty", "calories", "ingredients", "instructions", "imageKeyword", "type"],
    };

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            mealOfTheDay: recipeSchema,
            recommendations: {
              type: Type.ARRAY,
              items: recipeSchema,
            }
          },
          required: ["mealOfTheDay", "recommendations"],
        },
      },
    });

    if (response.text) {
      return JSON.parse(response.text);
    }
    throw new Error("No response from AI");
  } catch (error) {
    console.error("Error generating recipes:", error);
    throw error;
  }
}

export async function generateFoodSwap(foodName: string, calories: number) {
  try {
    const prompt = `The user scanned a packaged food: "${foodName}" which has ${calories} kcal. 
    It is flagged as unhealthy or high-calorie. 
    Suggest a healthier food alternative. Provide a short, actionable suggestion including the estimated calorie difference. 
    Example: "Replace with air-popped popcorn for -150 kcal."`;
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    
    return response.text;
  } catch (error) {
    console.error("Error generating food swap:", error);
    return "Consider a lighter alternative or smaller portion.";
  }
}

export async function chatWithCoach(message: string, userProfile: any, foodLogs: any[]) {
  try {
    const prompt = `You are an expert AI Nutrition Coach.
    User Profile: Goal: ${userProfile?.goal}, Diet: ${userProfile?.dietType}, Daily Calorie Goal: ${userProfile?.dailyCaloriesGoal} kcal.
    Recent Meals (last 5): ${JSON.stringify(foodLogs.slice(-5).map(l => ({ meal: l.foodItems, cals: l.totalCalories })))}
    
    User Message: "${message}"
    
    Provide a helpful, personalized, and concise response. If they ask "What should I eat today?" or "Is this good for fat loss?", use their data to answer accurately.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });

    return response.text;
  } catch (error) {
    console.error("Error chatting with coach:", error);
    throw error;
  }
}

export async function getWeeklyInsights(foodLogs: any[]) {
  try {
    const prompt = `Analyze these recent meals and provide 3 short, actionable insights about the user's eating habits.
    Meals: ${JSON.stringify(foodLogs.slice(-15).map(l => ({ date: l.date, items: l.foodItems, macros: l.macros, rating: l.healthRating })))}
    
    Example insight: "You overate carbs on weekends." or "Great job keeping protein high during lunch!"
    Return a JSON array of 3 strings.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
      },
    });

    if (response.text) {
      return JSON.parse(response.text);
    }
    return [];
  } catch (error) {
    console.error("Error getting insights:", error);
    return ["Eat more vegetables.", "Stay hydrated.", "Balance your macros."];
  }
}
